/*
Name: Joellen Allah-Mensah
Date: 3.16.2021
Class: csc1720
File Path: home/students/jallah/csc1720/prog3/unorderedArrayListType.h
About: This derived class file declares the prototypes of the unordered .cpp file 
*/

#include<string>
#ifndef UnorderedArrayList_TYPE
#define UnorderedArrayList_TYPE   
#include "arrayListType.h" 

template<class T>
class unorderedArrayListType: public arrayListType<T>
{
   using arrayListType<T>::maxSize;
   using arrayListType<T>::length;
   using arrayListType<T>::list; 

   public:
      //Constructor
      unorderedArrayListType(int size = 100);

      /*insertAt Function to insert insertItem in the list at the
        position specified by location.
        Note that this is an abstract function.
         Precondition: Starting at location, the elements of
                       the list are shifted down,
                       list[location] = insertItem; length++;
        Postcondition: If the list is full or location is
                       out of range, an appropriate message
                       is displayed.
      */
      void insertAt(int location, T insertItem);
  
      
        /*
        insertEnd Function to insert insertItem an item at the end of
        the list. Note that this is an abstract function.
        Precondition: list[length] = insertItem; and length++;
        Postcondition: If the list is full, an appropriate
                       message is displayed.
      */
      void insertEnd(T insertItem);
   
       /* replaceAt Function: replaces element if out of range
         Precondition: find if element location is between o and length
         Postcondition: output a cout message about element out of range
      */
      void replaceAt(int location, T repItem);
  

       /*seqSearch Function to search the list for searchItem.
        Note that this is an abstract function.
        Precondition: initializes variables for sequential search
        Postcondition: If the item is found, returns the
                       location in the array where the item
                       is found; otherwise, returns -1.
      */
      int seqSearch(T searchItem) const;

     

}; 
#include"unorderedArrayListType.cpp"
#endif
