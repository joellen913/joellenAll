/*
Name: Joellen Allah-Mensah
Date: 3.16.2021
Class: csc1720
File Path: home/students/jallah/csc1720/prog3/prog3Main.cpp

How to compile:
   g++ -Wall prog3main.cpp arrayListType.cpp unorderedArrayListType.cpp uniqueListType.cpp -o testProg
   (OR g++ -Wall *.cpp)

How to execute:
   ./testProg

Name of File:
   names.txt

About: This main file declares a templated string object of the derived 
       unorderedArrayList type and derived uniqueListType classes, and tests the
       base and derived methods for both, and includes external load
       function to load in first and last names from external textfile 
*/


#include<iostream>
#include<fstream>
#include<string>
#include<ctime>
#include<iomanip>
#include"uniqueListType.h"
#include"unorderedArrayListType.h"
#include"arrayListType.h"
using namespace std;

template<class T>
void loadData(unorderedArrayListType<T>& listA, uniqueListType<T>& listB);

/*
LoadData Function: external function to read in the datafile 
Pre-condition: Declares inFile and filename,
               loads in first and last names 
               uses insertEnd function to load in lists

Post-Condition: Assumption that it is called in main function
*/
template<class T>
void loadData(unorderedArrayListType<T>& listA, uniqueListType<T>& listB)
{
   ifstream inFile;
   string filename; 
   cin>>filename; //loads filename first 

   inFile.open(filename); //opens file
  
   string fName, lName;
   string fullN;
   while(!inFile.eof()) 
   {
      inFile>>fName>>lName;      
      fullN=fName+" "+ lName; //concatinate names
      listA.insertEnd(fullN);
      listB.insertEnd(fullN);
   }  
   inFile.close(); //close file
}
/*
 
Pre-condition: Declares templated string object of both derived classes,
               Prompts user for datafile, randomly selects winners,
               prompts user to enter costs per ticket and revenue,
               tests base and derived class functions
               calculates total profit of fundraiser

Post-Condition: Calls load data function, outputs list before and after
                use of functions, outputs result of sequential search, 
                outputs message revealing winners of each prize,
                outputs total calculated profit of fundraiser
*/
int main()
{

   ifstream inFile;
   unorderedArrayListType<string>listA; //declares 1st object
   uniqueListType<string>listB; //declares 2nd object

   cout<<endl;   
   cout<<setw(36)<<"FUNDRAISING RAFFLE!"<<endl; 
   cout<<endl;
   cout<<"Enter the Datafile name: ";  //prompts user to enter names.txt
   
  
   loadData(listA, listB); //calls external load function
   cout<<endl;    
  
   string winner; 
   int count=1;
   int winner1, winner2, winner3, winner4, grandwinner; 
   int size= sizeof(listA); //gets size if list from textfile

   srand(time(0)); //make sure rand() is different
   grandwinner=rand() % size; //sets variables = different random numbers
   winner1= rand() % size;
   winner2= rand() % size;
   winner3= rand() % size;
   winner4= rand() % size;
   
   //set prizes = variables
   string grandprize="PlayStation 5";
   string prize1="Dinner for Two at Blue Water Grille";
   string prize2="Set of 4 passes to Wet N Wild";
   string prize3="$100 Amazon Gift Card";
   string prize4="Set of 4 movie passes at the Palladium Regal Theater";
 

   cout<<"FUNDRAISER PRIZES"<<endl;
   cout<<endl; 

   //outputs potential fundraiser prizes
   cout<<"Grand Prize: "<<grandprize<<endl;
   cout<<"Prize 1: "<<prize1<<endl;
   cout<<"Prize 2: "<<prize2<<endl;
   cout<<"Prize 3: "<<prize3<<endl;
   cout<<"Prize 4: "<<prize4<<endl; 
   cout<<"_______________________"<<endl; 

   cout<<endl;
   cout<<"TESTING FUNCTIONS"<<endl;
   cout<<endl; 
  
                //FOR LISTA(unordered)

   //testing base class functions 
   cout<<setw(38)<<"<<LIST A>>"<<endl; 
   cout<<endl; 
   cout<<"List A Before Altering With Class Functions: "<<endl;
   cout<<endl; 
   listA.print(); //prints original listA list

   cout<<endl; 

   cout<<"List A After Using Class Functions: "<<endl; 
   cout<<endl; 

   //test class functions for listA
   listA.insertAt(0,"Joellen AllahMensah");
   listA.insertEnd("Zach Steinberg");
   listA.replaceAt(1,"Anaiya Rice");
   listA.replaceAt(5,"Gehna Sodhi");
   listA.removeAt(16);
   
   listA.print(); //print list after changes
 

   //testing seqSearch function
   cout<<endl; 
   cout<<"Testing Sequential Search:"<<endl; 
   string name = "Elliott Reese";

   if (listA.seqSearch(name)!= -1)
      cout<<name<<" is a duplicate in this list"<<endl;
   else 
      cout<<name<<" is not a duplicate in this list"<<endl;
   
   cout<<endl; 
                  //FOR LIST B (Unique)

   //testing base class functions
   cout<<setw(38)<<"<<LIST B>>"<<endl; 
   cout<<endl; 
   cout<<"List B Before Altering With Class Functions: "<<endl;
   cout<<endl;
   listB.print(); //prints original listA list

   cout<<endl;

   cout<<"List B After Using Class Functions: "<<endl;
   cout<<endl;

   //test class functions for listB
   listB.insertAt(0,"Eesha Kaul");
   listB.insertEnd("Savannah Graver");
   listB.replaceAt(8,"Arielle Silbert");
   listB.replaceAt(17,"Gehna Sodhi");
   listB.removeAt(23);

   listB.print(); //print list after changes


   //testing seqSearch function
   cout<<endl;
   cout<<"Testing Sequential Search:"<<endl;
   string name2 = "Logan Berger";

   if (listB.seqSearch(name2)!= -1)
      cout<<name2<<" is a duplicate in this list"<<endl;
   else
      cout<<name2<<" is not a duplicate in this list"<<endl;
   cout<<"_______________________"<<endl;

  

   cout<<endl;
   cout<<"WINNERS"<<endl; 
   cout<<endl; 

   while(count<6) 
   {
      //multiple if statements to output specific prize at specific count
      //multiple calls to getAt function to get winners name at rand() 
      //uses listB to ensure winners are unique each time
         cout<<"The winner of the ";
         if(count==1)
         {
            cout<<grandprize; 
            cout<<" is ";
            cout<<listB.getAt(grandwinner); //uses unique list B
            cout<<"!"<<endl;

         }else if(count==2){
            cout<<prize1;
            cout<<" is ";
            cout<<listB.getAt(winner1);
            cout<<"!"<<endl;
         

         }else if(count==3){
            cout<<prize2;
            cout<<" is ";
            cout<<listB.getAt(winner2);
            cout<<"!"<<endl;
         

         }else if(count==4){
            cout<<prize3;
            cout<<" is ";
            cout<<listB.getAt(winner3);
            cout<<"!"<<endl;

         }else if(count==5){
            cout<<prize4;
            cout<<" is ";
            cout<<listB.getAt(winner4);
            cout<<"!"<<endl;
            cout<<endl;
         }
         count++; //increment count
   }
    
    cout<<"_______________________"<<endl;
   //CALCULATE PROFIT
   cout<<endl; 

   double costPerTicket, revenue, profit, costs;
   double costOfPrizes=190.75; //estimated cost to buy prizes leaving out donated prizes

   cout<<"FUNDRAISER PROFIT"<<endl;
   cout<<endl; 

   cout<<"Enter the cost per ticket: "; //prompt user cost per ticke
   cin>>costPerTicket;
   
   
   cout<<"Enter the total revenue of the fundraiser: "; //prompt user revenue
   cin>>revenue; 

   //calculation
   costs=(costPerTicket*size)+costOfPrizes; //total $ spent to make fundraiser
   profit = revenue-costs; //money made from fundraiser taking into account costs
   cout<<"Total Calculated Profit: $"<<profit<<endl; //output profit 
   
  

 
   return 0;
}

