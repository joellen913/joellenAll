/*
Name: Joellen Allah-Mensah
Date: 3.16.2021
Class: csc1720
File Path: home/students/jallah/csc1720/lab8/uniqueListType.cpp
About: This file includes the methods of the unique class file
*/

#include <iostream>
#include"arrayListType.h"
#include "unorderedArrayListType.h"
//#include"uniqueListType.h"
#include <string>
using namespace std;

//calls constructor from unorderedArrayListType
template <class T> 
uniqueListType<T>::uniqueListType(int size)
               : unorderedArrayListType<T>(size)
{
}  //end constructor

//calls insertAt and seqSearch function from unorderedArrayListType
template <class T>
void uniqueListType<T>::insertAt(int location, T insertItem)
{
   if(unorderedArrayListType<T>::seqSearch(insertItem)==-1)
      unorderedArrayListType<T>::insertAt(location, insertItem);
 
} //end insertAt

//calls insertEnd function from unorderedArrayListType
template <class T>
void uniqueListType<T>::insertEnd(T insertItem)
{
   if(unorderedArrayListType<T>::seqSearch(insertItem)==-1)
      unorderedArrayListType<T>::insertEnd(insertItem);
      
} //end insertEnd


//calls replaceAt function from unorderedArrayListType
template <class T>
void uniqueListType<T>::replaceAt(int location, T repItem)
{
   if(unorderedArrayListType<T>::seqSearch(repItem)==-1)
      unorderedArrayListType<T>::replaceAt(location, repItem);
} //end replaceAt


