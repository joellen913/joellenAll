/*
Name: Joellen Allah-Mensah
Date: 3.16.2021
Class: csc1720
File Path: home/students/jallah/csc1720/lab8/uniqueListType.h
About: This derived class file declares the prototypes of the unique .cpp file
*/

#include<string>
#ifndef UniqueList_TYPE
#define UniqueList_TYPE
#include"arrayListType.h"
#include"unorderedArrayListType.h"
template<class T>
class uniqueListType: public unorderedArrayListType<T>
{
   public:

      //constructor
      uniqueListType(int size=100);
   
      /*insertAt Function to insert insertItem in the list at the
        position specified by location.
        Note that this is an abstract function.
         Precondition: Starting at location, the elements of
                       the list are shifted down,
                       list[location] = insertItem; length++;
        Postcondition: If the list is full or location is
                       out of range, an appropriate message
                       is displayed.
      */

      void insertAt(int location, T insertItem);

      
        /*
        insertEnd Function to insert insertItem an item at the end of
        the list. Note that this is an abstract function.
        Precondition: list[length] = insertItem; and length++;
        Postcondition: If the list is full, an appropriate
                       message is displayed.
      */

      void insertEnd(T insertItem);

       /* replaceAt Function: replaces element if out of range
         Precondition: find if element location is between o and length
         Postcondition: output a cout message about element out of range
      */
      
      void replaceAt(int location, T repItem);
       
};
#include"uniqueListType.cpp"
#endif

