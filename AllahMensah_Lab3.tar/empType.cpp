/* 
   Author: Joellen Allah-Mensah
   Date: 1/26/2021
   Class: CSC-1720
   Code location: home/students/jallah/csc1720/lab3/empType.cpp
   
   About: Implementation file provides functions for each member of class
*/

#include"empType.h"

//pre-condition: private member name is set equal to setName in parameter iname
//post-condition: name becomes iname
void empType::setName(string iname)
{
   name = iname;
}

//pre-condition: private member age is set equal to setAge in parameter iage
//post-condition: age becomes iage
void empType::setAge(int iage)
{
   age = iage;
}

//pre-condition: private member salary is set equal to setSalary in parameter iSalary
//post-condition: salary becomes isalary
void empType::setSalary(double isalary)
{
   salary = isalary;
   
}

//pre-condition: private member id is set equal to setId parameter ID
//post-condition: id becomes ID 
void empType::setId(int ID)
{
   id = ID;
}

//pre-condition: name already declared, no precondition
//post-condition: returns name back to parameter in setName
string empType::getName(void) const
{
   return name;
}

//pre-condition: age already declared, no precondition
//post-condition: returns age back to parameter in setAge
int empType::getAge(void) const
{
   return age;
}

//pre-condition: salary already declared, no pre-condition
//post-condition: returns salary back to parameter in setSalary
double empType::getSalary(void) const
{
   return salary;
}

//pre-condition: id has already been declared, no precondition
//post-condition: returns the id back to parameter in setId
int empType::getId(void) const
{
   return id;
}

//pre-condition: name, age, salary, and id are stated by user
//post-condition: sets name, age, salary, or id equal to default
empType::empType()
{
   name="John Doe";
   age=0;
   salary=0;
   id=0; 
}

//pre-condition: name, age, salary, or id that is invalid may be inputted by user
//post-condition: incase the user enters and invalid input
//                the cerr will output a message 
empType::empType(string name, int age, double salary, int id)
{
   if (name==" ")
      cerr<<"Error: name not valid"<<endl; 

   if(age<17)
      cerr<<"Error: too young"<<endl;
   
   if(salary<0)
      cerr<<"Error: Salary is negative, must be positive"<<endl;
      
   if(id<0)
      cerr<<"Error: id must be positive"<<endl; 
}


