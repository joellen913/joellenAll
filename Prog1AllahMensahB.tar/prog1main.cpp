/*
   Name: Joellen Allah-Mensah
   Date Started: 1/24/2021
   Class: Adv programming w/ Data Structures
   About: This main program utilizes the countertype class to count 
          characters and words as specified in the program levels below

   Aimed Grade Level: B (85%) 

   How to compile:
      g++ -Wall prog1main.cpp prog1implementation.cpp -o testProg

   How to execute:
      ./testProg 
       sample textfile to put when prompted: "seuss.txt" 

   Pre-condition: When file is prompted to be inputted, file is 
                  stored, and renamed with the getline function. 
                  Objects from class and infile are declared,

   Post-condition: number of characters, vowels, and sentences in 
                   passage are outputted, and the sentence with the
                   greatest number of words, and the number of words
                   in that sentence are outputted.
*/

#include"counterType.h"  //Preprocessor directives
#include<iostream> 
#include<fstream>
#include<cstring>
#include<iomanip>
#include<string> 
using namespace std;

int main()
{
   string filename;  //variables including class objects and infile declaration 
   string passage; 
   counterType chars;
   counterType vowels;
   counterType sentences;
   counterType topSent; 
   counterType wordsInSent; 
   ifstream infile;
   int total=0; 
   
   cout<<"Enter the input file name: ";  //asks user to input file name 
   cin>>filename;

   infile.open(filename.c_str());  //opens file
      
   while(infile) //loads in textfile 
   {
      getline(infile, passage); //gives file variable name "passage" 

      //PROMPT 1: number of characters in passage 
      int len=passage.length(); 
      total+=len; 
             
      //PROMPT 2: number of vowels in passage 
      for(int i=0; i<len;i++)
      {      
       //if the passage includes vowel, increment function is used from class
         if(passage[i]=='A'|| passage[i]=='a')  
            vowels.incrementCounter();         
         else if(passage[i]=='E'||passage[i]=='e') 
            vowels.incrementCounter();
         else if(passage[i]=='I'||passage[i]=='i')
            vowels.incrementCounter();
         else if(passage[i]=='O'||passage[i]=='o')
            vowels.incrementCounter(); 
         else if(passage[i]=='U'||passage[i]=='u')
            vowels.incrementCounter();  
      }

      //PROMPT 3: number of sentences in passage
      for(int i=0; i<len; i++) 
      {
      //if passage contains ending punctuation, increment function is used
      // from class, and numOfSents counter is counts sentences
         int numOfSents; 
         if(passage[i]=='.')
         {                                 
            sentences.incrementCounter();
            numOfSents++; 
         }else if(passage[i]=='!')
         {
            sentences.incrementCounter();
            numOfSents++; 
         }
         else if(passage[i]=='?')
         {
            sentences.incrementCounter();
            numOfSents++; 
         }
      
      }     

   
   chars.setCounter(total);  //calls the total # of chars outside loop
      
  
      
   }//close while loop 
 
   cout<<"Passage from "<<filename<<endl;  
                        
  //outputs the results of each prompt using functions from implementation file               
   cout<<setw(22)<<"Number of chars: ";
   chars.displayCounter();
                         
   cout<<setw(23)<<"Number of vowels: ";
   vowels.displayCounter();
   
   cout<<setw(26)<<"Number of sentences: ";
   sentences.displayCounter();
   cout<<endl; 
   

   infile.close();  //closes file

   return 0; 

}


