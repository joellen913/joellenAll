/*
   Name: Joellen Allah-Mensah
   Date: 1/24/2021
   Class: Adv programming in Data structures
   File Location: /home/students/jallah/csc1720/prog1implementation.cpp

   About: Implementation file contains the functions used to count,
          initialize, set, and get the vowels, characters, sentences,
          and words in the given textfile
*/

#include<iostream>
#include"counterType.h"
using namespace std;

//Pre-condition: object has not yet been initialized
//Post-condition: sets counter equal to x parameter  
counterType::counterType(int x)
{
   counter=x;
}

//Pre-condition: object has not yet been initialized
//Post-condition: defaults the counter to zero
counterType::counterType()
{
   counter=0;
}

//Pre-condition: object has not yet been initialized
//Post-condition: defaults the counter to zero
void counterType::initializeCounter()
{
   counter=0;
}


//Pre-condition: object has not yet been initialized
//Post-condition: outputs counter value if greater than or equal to 0,
//                if negative, outputs a 0
void counterType::displayCounter() const
{
   if (counter>=0)
      cout<<counter<<endl;
   else
      cout<<"0"<<endl;
}


//Pre-condition: object has not yet been initialized
//Post-condition: redefines counter as integer "x"
void counterType::setCounter(int x)
{
   counter=x;
}

//Pre-condition: object has not yet been initialized
//Post-condition: if counter is greater than zero, returns counter
//                if counter is negative, counter returns a zero
int counterType::getCounter() const
{
   if (counter>=0)
      return counter;
   else
      return 0;
}

//Pre-condition: object has not yet been initialized
//Post-condition: if the counter is zero or a positive #, increment
//                if the counter is a negative, counter defaults to zero 
void counterType::incrementCounter()
{
   if(counter>=0)
      counter++;
   else
      counter=0;
}

//Pre-condition: object has not yet been initialized
//Post-condition: if the counter is zero or a positive #, decrements
//                if the counter is a negative, counter defaults to zero
void counterType::decrementCounter()
{
   if(counter>=0)
      counter--;
   else
      counter=0;
}
