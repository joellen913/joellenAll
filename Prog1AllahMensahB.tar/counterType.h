/*
   Name:Joellen Allah-Mensah
   Date: 1/19/2021
   Class:Adv Programming with Data Structures
   Code Location: home/students/jallah/csc1720/counterType.h
   About: This headerfile defines the private and public members of the class
*/

#ifndef COUNTER_TYPE
#define COUNTER_TYPE

//precondition: defines class with private and public members, 
//              initializes the appropriate class variables 
//post-condition: class has not been declared yet
class counterType
{
private:
   int counter;
public:
   void initializeCounter();
   void setCounter(int x=0);
   int getCounter() const;
   void incrementCounter();
   void decrementCounter();
   void displayCounter() const;
   counterType (int counter);
   counterType();
};

#endif
