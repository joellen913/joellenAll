/*Joellen Allah-Mensah
1/12/2021
Adv programming in Data structures
/home/students/jallah/csc1720/lab1/counterType.cpp
This program will use a class to create the appropriate implementations to alter three numbers
*/
#include<iostream>
#include"counterType.h"
using namespace std;

//sets counter equal to integer x
counterType::counterType(int x)
{
   counter=x;
}

//defaults counter to zero 
counterType::counterType()
{
   counter=0;
}

//initializes counter value to zero
void counterType::initializeCounter()
{
   counter=0;
}

//outputs counter value if greater than or equal to 0
void counterType::displayCounter() const
{
   if (counter>=0)
      cout<<counter<<endl;
   else 
      cout<<"0"<<endl;  
}

//redefines counter as integer "x"
void counterType::setCounter(int x)
{
   counter=x;
}

//returns counter value
int counterType::getCounter() const
{
   if (counter>=0)
      return counter;
   else
      return 0; 
}

//if counter is 0 or greater, increment
void counterType::incrementCounter()
{
   if(counter>=0)
      counter++;
   else
      counter=0; 
}

//if counter is 0 or greater, decrement
void counterType::decrementCounter()
{
   if(counter>=0)
      counter--;
   else
      counter=0; 
}
