/*Joellen Allah-Mensah
09/13/2023
CSC4510 - Prog Lang Design/Translation 
File location: /home/students/jallah/csc4510/assignment2/callby.cpp
About: This Java program is a practical resource that explores
C++ parameter passing methods and memory management. It demonstrates the
five parameter passing techniques: pass by value, reference, value-result,
value, and result, and highlights the impact of multiple names referencing
the same memory location, discusses the consequences of deleting
memory, and addresses pointer-related issues. 

We compile this file with the command:
   javac callby.java

We create an executable file called callby, which can then be executed by typing:
   java callby

*/


public class callby {
    public static void main(String[] args) {
        System.out.println();
        
        // ------------- call by value -------------
        System.out.println("Call By Value");
        int x = 42;
        int name1 = x;
        int name2 = x;
        callByValue(name1, name2);

        System.out.println();
        System.out.println();
        System.out.println();

        System.out.println("Call By Reference");

        // ------------- call by reference (pointers) -------------
        int num = 5;
        System.out.println("Before function call: num = " + num);
        callByReference(num);
        System.out.println("After function call: num = " + num);

        System.out.println();
        System.out.println();

        // ------------- call by value result -------------
        System.out.println("Call By Value-Result");
        int num1 = 5;
        int num2 = 10;
        System.out.println("Before swap: num1 = " + num1 + ", num2 = " + num2);
        valueResult(num1, num2);
        System.out.println("After swap: num1 = " + num1 + ", num2 = " + num2);

        System.out.println();
        System.out.println();

        // ------------- call by result -------------
        System.out.println("Call By Result:");
        int element = 5;
        callByResult(element);
        System.out.println(element);

        System.out.println();
        System.out.println();

        // ------------- call by name -------------
        System.out.println("Call By Name:");
        int item = 200;
        System.out.println("Before invoking callByName function: " + item);
        callByName(item);
        System.out.println("After invoking callByName function: " + item);
    }

    /* ------------------------- CALL BY VALUE FUNCTION ---------------------
     About Function:
     This function sets an integer variable to 42, displays it,
     modifies it to 100, and then displays it again, highlighting
     how multiple names exist to refer to the same memory location
    */
    public static void callByValue(int name1, int name2) {
        int x = 42;
        System.out.println("x: " + x);
        System.out.println("name1: " + name1);
        System.out.println("name2: " + name2);
        System.out.println();
        name1 = 100;
        System.out.println("Name1 variable after change: " + x);
        System.out.println("name1 after change: " + name1);
        System.out.println("name2 after change: " + name2);
    }

    /* ------------------------- CALL BY REFERENCE FUNCTION ---------------------
     About Function:
     This function creates a new integer, adds 10 to it,
     and highlights how deleting memory location affects the address
    */
    public static void callByReference(int num) {
        num += 10;
    }

    /* ------------------------- CALL BY VALUE-RESULT FUNCTION ---------------------
     About Function:
     The function swaps the values of two integer references, a and b,
     using a temporary variable. This swapping operation allows for the
     exchange of values between the two referenced variables
    */
    public static void valueResult(int a, int b) {
        int temp = a;
        a = b;
        b = temp;
    }

    /* ------------------------- CALL BY RESULT FUNCTION ---------------------
     About Function:
     This function attempts to add 10 to the number parameter but doesn't
     store or return the result. So the addition operation has
     no effect on the number variable outside the function, as it doesn't
     modify or return any value.
    */
    public static void callByResult(int number) {
        System.out.println("10 Added to number: ");
        number += 10;
    }

    /* ------------------------- CALL BY NAME FUNCTION ---------------------
     About Function:
     This function multiplies the value pointed to by the val pointer by 100
     and assigns the result back to the same memory location. It then returns
     the different value.
    */
    public static int callByName(int val) {
        val = 15 * 100; // assigns pointer to value multiplied
        return val;
    }
}
