How to use Each Program: 

Program 1: callby.cpp  
To execute program: g++ callby.cpp  

This program This C++ program demonstrates the five parameter passing
techniques: pass by value, reference, value-result, value, and result,
and highlights the impact of multiple names referencing the same memory
location, discusses the consequences of deleting
memory, and addresses pointer-related issues. 


Main Function ( )
Calls each function, only initializes variables for call by value,
rest are initialized within their own functions 


Functions: 

Void CallByValue: 
This function sets an integer variable to 42, displays it,
 modifies it to 100, and then displays it again, highlighting
 how multiple names exist to refer to same memory location

Void Callbyreference: 
This function creates a new pointer and allocates it with new memory space,
 then adds 10 to the integer, then deallocates the space created for the pointer,
 highlighting how deleting memory location affects the address


Void valueresult: 
The function swaps the values of two integer references, a and b,
 using a temporary variable. This swapping operation allows for the
 exchange of values between the two referenced variables

Void callbyresult: 
This function attempts to add 10 to the number parameter but doesn't
 store or return the result. So the addition operation has
 no effect on the number variable outside the function, as it doesn't
 modify or return any value. 

Int callbyname:
This function multiplies the value pointed to by the val pointer by 100
and assigns the result back to the same memory location. It then returns
the modified value.


When Executed: 
Will output all the functions at once, demonstrating the ways each
parameter passing mechanism will differ 

Sample Output for Call By Value

Call By Value 
x: 42
name1: 42
name2: 42

Name1 variable after change: 42
name1 after change: 100
name2 after change: 42


______________


Program 2: callby.java
To execute program: javac callby

(same purpose as previous functions) 

When Executed: 
Will output all functions at once, you will see the difference between
the outputs of the C++ program versus the Java file 

Sample Output for Call By Reference

Call By Reference
Before function call: num = 5
After function call: num = 5

 
