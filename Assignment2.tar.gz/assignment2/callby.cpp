
/*Joellen Allah-Mensah
09/13/2023
CSC4510 - Prog Lang Design/Translation 
File location: /home/students/jallah/csc4510/assignment2/callby.cpp
About: This C++ program demonstrates the five parameter passing
techniques: pass by value, reference, value-result, value, and result,
and highlights the impact of multiple names referencing the same memory
location, discusses the consequences of deleting
memory, and addresses pointer-related issues. 

We compile this file with the command:
   g++ callby.cpp -o callby

We create an executable file called callby, which can then be executed by typing:
   ./callby

*/


//preprocessor directives
#include <iostream>
using namespace std;

// functions 
void callbvalue(int name1, int name2); 
void callbyreference(int *x); 
void valueresult(int &a, int &b); 
void callbyresult(int number);
int callbyname(int*);

// ------------------------- MAIN () ---------------------
int main() 
{
cout << endl;  
    // ------------- call by value ------------- 
    cout << "Call By Value " << endl; 
    int x = 42; 
    int &name1 = x; // Create a reference 'name1' that refers to 'x'
    int &name2 = x; // Create another reference 'name2' that also refers to 'x'
    callbvalue(name1, name2); // calls call by value function 

    cout << endl; 
    cout << endl; 
    cout << endl;

    cout << "Call By Reference " << endl; 


    // ------------- call by reference (pointers) -------------
    int num = 5;
    cout << "Before function call: num = " << num << endl; // Output: Before function call: num = 5

    
    callbyreference(&num); 

    cout << "After function call: num = " << num << endl;
    cout << endl; 
    cout << endl;

    // ------------- call by value result -------------
    cout << "Call By Value-Result " << endl; 

    int num1 = 5;
    int num2 = 10;

    cout << "Before swap: num1 = " << num1 << ", num2 = " << num2 << endl; // Output: Before swap: num1 = 5, num2 = 10

    valueresult(num1, num2); // Call the valueresult function to swap 'num1' and 'num2'

    cout << "After swap: num1 = " << num1 << ", num2 = " << num2 << endl; // Output: After swap: num1 = 10, num2 = 5
    cout << endl; 
    cout << endl;

   //  ------------- call by result -------------
   cout << endl;
   cout << "Call By Result: " << endl;
   int element=5; 
   callbyresult(element); //calls result function 
   cout << element << endl; 

   cout << endl; 
   cout << endl; 
    cout << endl;

   // ------------- call by name -------------
   cout << "Call By Name: " << endl;
   int item = 200;  
   cout << "Before evoking callbyname function: " << item << " " << endl; 
   callbyname(&item); // calls name function
   cout << "After evoking callbyname function: " << item << endl;

    return 0; 
} 


/* ------------------------- CALL BY VALUE FUNCTION ---------------------
 About Function: 
 This function sets an integer variable to 42, displays it,
 modifies it to 100, and then displays it again, highlighting
 how multiple names exist to refer to same memory location
*/
void callbvalue(int name1, int name2) {

    int x = 42; // assigns value to x

    cout << "x: " << x << endl;       
    cout << "name1: " << name1 << endl; // Output: name1: 42
    cout << "name2: " << name2 << endl; // Output: name2: 42

    cout << endl; 
    
    name1 = 100; //changes value of name1 to show comparison

    cout << "Name1 variable after change: " << x << endl; // Output: x after modification
    cout << "name1 after change: " << name1 << endl; // Output: name1 after modification
    cout << "name2 after change: " << name2 << endl; // Output: name2 after modification

}

/* ------------------------- CALL BY REFERENCE FUNCTION ---------------------
 About Function: 
 This function creates a new pointer and allocates it with new memory space,
 then adds 10 to the integer, then deallocates the space created for the pointer,
 highlighting how deleting memory location affects the address
*/
void callbyreference(int *x) {
    x = new int; 

    (*x) += 10; // Increment the value pointed to by 'x' by 10
    delete x; 
}

/* ------------------------- CALL BY VALUE-RESULT FUNCTION ---------------------
 About Function: 
 The function swaps the values of two integer references, a and b,
 using a temporary variable. This swapping operation allows for the
 exchange of values between the two referenced variables
*/ 
void valueresult(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}


/* ------------------------- CALL BY RESULT FUNCTION ---------------------
 About Function: 
 This function attempts to add 10 to the number parameter but doesn't
 store or return the result. So the addition operation has
 no effect on the number variable outside the function, as it doesn't
 modify or return any value. 
*/  

//call by result
void callbyresult(int number)
{
   cout << "10 Added to number: ";
   number + 10; 
}


/* ------------------------- CALL BY NAME FUNCTION ---------------------
About Function: 
This function multiplies the value pointed to by the val pointer by 100
and assigns the result back to the same memory location. It then returns
the modified value.
*/


int callbyname(int* val)
{
   *val=15 * 100; //assigns pointer to value multiplied 
   return *val;
   
}










